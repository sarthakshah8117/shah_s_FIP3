# PORTFOLIO

![project image](images/readme.jpg)

> FRONT END WEB DEVELOPER
---
### Table of contents

- [Description](#description)
- [References](#references)
- [Author](#author)

---

## Description

This is my portfolio piece. It is assigned as course Final Integrated Project fall, 2020. This is my identity where i have displayed my work and skills. The link below will drive through the steps that are followed.  

[Roadmap](https://docs.google.com/document/d/1YL0Rwm_6ZIpF-uMk887ElBv_TaUnrZ1gJTBQC7985Xc/edit)

### Technologies 

Following are the softwares which i have used to designed elements of portfolio and langauages that are used for coding:

- Git bash
- Visual Studio Code
- Photoshop
- illustrator
- Adobe XD
- Adobe InDesign
- HTML
- CSS
- Javascript
- SASS
- AJAX
- Vue
- SQL, MYSQL
- PHP

---

## References
- W3schools
- youtube
- MDN learning

---

## Author

Sarthak Shah





